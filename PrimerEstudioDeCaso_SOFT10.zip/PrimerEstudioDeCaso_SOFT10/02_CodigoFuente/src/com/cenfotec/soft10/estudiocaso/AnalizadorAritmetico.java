package com.cenfotec.soft10.estudiocaso;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Contiene la lógica del estudio de caso:
 *  1. Tokenización de la cadena de entrada.
 *  2. Validación de balanceo de paréntesis usando la Pila personalizada.
 *  3. Conversión de infija a postfija (algoritmo de Shunting-yard).
 *  4. Evaluación de la expresión postfija con valores de variables.
 *
 * @author Estudiante de Ingeniería en Software - Universidad CENFOTEC
 * @version 1.0
 */
public class AnalizadorAritmetico {

    /** Registro de pasos para la visualización paso a paso de la pila. */
    private List<String> registroPasos;

    /**
     * Constructor del analizador.
     */
    public AnalizadorAritmetico() {
        this.registroPasos = new ArrayList<>();
    }

    /** @return registro de pasos del último análisis realizado */
    public List<String> getRegistroPasos() {
        return registroPasos;
    }

    /**
     * Separa una expresión aritmética en tokens léxicos.
     * Reconoce números (enteros y decimales), variables alfabéticas,
     * operadores + - * / y paréntesis. Ignora los espacios en blanco.
     *
     * @param expresion cadena de entrada, ej. "a + (b * 5)"
     * @return lista ordenada de tokens
     * @throws IllegalArgumentException si aparece un carácter no válido
     */
    public List<Token> tokenizar(String expresion) {
        List<Token> tokens = new ArrayList<>();
        int i = 0;
        while (i < expresion.length()) {
            char c = expresion.charAt(i);

            if (Character.isWhitespace(c)) {
                i++; // Los espacios no son tokens
            } else if (Character.isDigit(c) || (c == '.' && i + 1 < expresion.length()
                        && Character.isDigit(expresion.charAt(i + 1)))) {
                // Acumular número completo (entero o decimal)
                StringBuilder numero = new StringBuilder();
                boolean puntoUsado = false;
                while (i < expresion.length()) {
                    char d = expresion.charAt(i);
                    if (Character.isDigit(d)) {
                        numero.append(d);
                        i++;
                    } else if (d == '.' && !puntoUsado) {
                        numero.append(d);
                        puntoUsado = true;
                        i++;
                    } else {
                        break;
                    }
                }
                tokens.add(new Token(numero.toString(), Token.TipoToken.NUMERO));
            } else if (Character.isLetter(c)) {
                // Acumular nombre completo de la variable
                StringBuilder variable = new StringBuilder();
                while (i < expresion.length() && Character.isLetterOrDigit(expresion.charAt(i))) {
                    variable.append(expresion.charAt(i));
                    i++;
                }
                tokens.add(new Token(variable.toString(), Token.TipoToken.VARIABLE));
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                tokens.add(new Token(String.valueOf(c), Token.TipoToken.OPERADOR));
                i++;
            } else if (c == '(') {
                tokens.add(new Token("(", Token.TipoToken.PARENTESIS_IZQ));
                i++;
            } else if (c == ')') {
                tokens.add(new Token(")", Token.TipoToken.PARENTESIS_DER));
                i++;
            } else {
                throw new IllegalArgumentException("Carácter no válido en la expresión: '" + c + "'");
            }
        }
        return tokens;
    }

    /**
     * Verifica que todos los paréntesis estén correctamente balanceados
     * usando la Pila personalizada (LIFO).
     *
     * @param tokens lista de tokens de la expresión
     * @return mensaje descriptivo del resultado de la validación
     */
    public String verificarBalanceo(List<Token> tokens) {
        registroPasos.clear();
        Pila pila = new Pila();
        registroPasos.add("=== VALIDACIÓN DE PARÉNTESIS ===");

        for (Token token : tokens) {
            if (token.getTipo() == Token.TipoToken.PARENTESIS_IZQ) {
                pila.push(token);
                registroPasos.add("Token '(' -> PUSH. Pila: " + pila.contenidoComoLista());
            } else if (token.getTipo() == Token.TipoToken.PARENTESIS_DER) {
                if (pila.estaVacia()) {
                    registroPasos.add("Token ')' -> ERROR: paréntesis de cierre sin apertura.");
                    return "EXPRESIÓN NO BALANCEADA: existe un ')' sin su '(' correspondiente.";
                }
                pila.pop();
                registroPasos.add("Token ')' -> POP (emparejado con '('). Pila: " + pila.contenidoComoLista());
            }
        }

        if (!pila.estaVacia()) {
            registroPasos.add("Fin de la expresión -> ERROR: quedan " + pila.getTamaño()
                    + " paréntesis sin cerrar.");
            return "EXPRESIÓN NO BALANCEADA: existen " + pila.getTamaño()
                    + " paréntesis de apertura sin cerrar.";
        }
        registroPasos.add("Fin de la expresión -> pila vacía. BALANCEO CORRECTO [OK]");
        return "EXPRESIÓN BALANCEADA CORRECTAMENTE [OK]";
    }

    /**
     * Convierte una expresión infija a postfija usando el algoritmo
     * de Shunting-yard con la Pila personalizada para operadores.
     *
     * @param tokens lista de tokens (previamente validada)
     * @return lista de tokens en notación postfija (polaca inversa)
     * @throws IllegalArgumentException si la expresión es sintácticamente inválida
     */
    public List<Token> convertirAPostfija(List<Token> tokens) {
        List<Token> salida = new ArrayList<>();
        Pila operadores = new Pila();

        for (Token token : tokens) {
            switch (token.getTipo()) {
                case NUMERO:
                case VARIABLE:
                    salida.add(token); // Operandos van directamente a la salida
                    break;

                case OPERADOR:
                    // Desapilar operadores de mayor o igual precedencia
                    while (!operadores.estaVacia()
                            && operadores.peek().esOperador()
                            && operadores.peek().getPrecedencia() >= token.getPrecedencia()) {
                        salida.add(operadores.pop());
                    }
                    operadores.push(token);
                    break;

                case PARENTESIS_IZQ:
                    operadores.push(token);
                    break;

                case PARENTESIS_DER:
                    // Vaciar hasta encontrar el '(' emparejado
                    while (!operadores.estaVacia()
                            && operadores.peek().getTipo() != Token.TipoToken.PARENTESIS_IZQ) {
                        salida.add(operadores.pop());
                    }
                    if (operadores.estaVacia()) {
                        throw new IllegalArgumentException("Paréntesis desbalanceados en la conversión.");
                    }
                    operadores.pop(); // Descartar el '('
                    break;
            }
        }

        // Vaciar los operadores restantes
        while (!operadores.estaVacia()) {
            Token restante = operadores.pop();
            if (restante.getTipo() == Token.TipoToken.PARENTESIS_IZQ) {
                throw new IllegalArgumentException("Paréntesis desbalanceados: falta un ')'.");
            }
            salida.add(restante);
        }
        return salida;
    }

    /**
     * Evalúa una expresión en notación postfija.
     * Los valores de las variables se consultan en el mapa proporcionado.
     *
     * @param postfija lista de tokens postfijos
     * @param valores  mapa nombreDeVariable -> valor numérico
     * @return resultado numérico de la expresión
     * @throws IllegalArgumentException si faltan valores o la expresión es inválida
     */
    public double evaluarPostfija(List<Token> postfija, Map<String, Double> valores) {
        Pila operandos = new Pila();

        for (Token token : postfija) {
            switch (token.getTipo()) {
                case NUMERO:
                    operandos.push(new Token(token.getValor(), Token.TipoToken.NUMERO));
                    break;

                case VARIABLE:
                    if (!valores.containsKey(token.getValor())) {
                        throw new IllegalArgumentException(
                                "No se proporcionó valor para la variable '" + token.getValor() + "'");
                    }
                    operandos.push(new Token(String.valueOf(valores.get(token.getValor())),
                            Token.TipoToken.NUMERO));
                    break;

                case OPERADOR:
                    if (operandos.getTamaño() < 2) {
                        throw new IllegalArgumentException(
                                "Expresión inválida: el operador '" + token.getValor()
                                        + "' no tiene suficientes operandos.");
                    }
                    double derecho = Double.parseDouble(operandos.pop().getValor());
                    double izquierdo = Double.parseDouble(operandos.pop().getValor());
                    double resultado = aplicarOperacion(izquierdo, derecho, token.getValor());
                    operandos.push(new Token(String.valueOf(resultado), Token.TipoToken.NUMERO));
                    break;

                default:
                    throw new IllegalArgumentException("Token inesperado en la evaluación: " + token);
            }
        }

        if (operandos.getTamaño() != 1) {
            throw new IllegalArgumentException("Expresión inválida: sobran operandos sin operar.");
        }
        return Double.parseDouble(operandos.pop().getValor());
    }

    /**
     * Aplica una operación aritmética binaria.
     *
     * @param a        operando izquierdo
     * @param b        operando derecho
     * @param operador +, -, * o /
     * @return resultado de la operación
     * @throws ArithmeticException      en división entre cero
     * @throws IllegalArgumentException si el operador es desconocido
     */
    private double aplicarOperacion(double a, double b, String operador) {
        switch (operador) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/":
                if (b == 0) {
                    throw new ArithmeticException("División entre cero no permitida.");
                }
                return a / b;
            default:
                throw new IllegalArgumentException("Operador no soportado: " + operador);
        }
    }
}

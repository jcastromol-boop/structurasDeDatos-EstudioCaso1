package com.cenfotec.soft10.estudiocaso;

/**
 * Representa un token (componente léxico) de una expresión aritmética.
 * Además, cada Token actúa como un Nodo de la pila enlazada,
 * por lo que contiene un puntero al siguiente nodo.
 *
 * @author Estudiante de Ingeniería en Software - Universidad CENFOTEC
 * @version 1.0
 */
public class Token {

    /** Tipos de tokens reconocidos por el analizador léxico. */
    public enum TipoToken {
        NUMERO,           // Literales numéricos: 5, 3.14, 42
        VARIABLE,         // Identificadores: a, b, x1, resultado
        OPERADOR,         // +, -, *, /
        PARENTESIS_IZQ,   // (
        PARENTESIS_DER    // )
    }

    /** Valor textual del token (ej. "+", "5", "b"). */
    private String valor;

    /** Categoría del token dentro de la gramática. */
    private TipoToken tipo;

    /** Puntero al siguiente nodo de la pila enlazada. */
    private Token siguiente;

    /**
     * Crea un nuevo token (y nodo de pila).
     *
     * @param valor contenido textual del token
     * @param tipo  categoría léxica del token
     */
    public Token(String valor, TipoToken tipo) {
        this.valor = valor;
        this.tipo = tipo;
        this.siguiente = null;
    }

    /** @return valor textual del token */
    public String getValor() {
        return valor;
    }

    /** @param valor nuevo valor textual */
    public void setValor(String valor) {
        this.valor = valor;
    }

    /** @return tipo del token */
    public TipoToken getTipo() {
        return tipo;
    }

    /** @param tipo nuevo tipo del token */
    public void setTipo(TipoToken tipo) {
        this.tipo = tipo;
    }

    /** @return nodo siguiente en la pila (null si es el último) */
    public Token getSiguiente() {
        return siguiente;
    }

    /** @param siguiente nodo que quedará debajo de este en la pila */
    public void setSiguiente(Token siguiente) {
        this.siguiente = siguiente;
    }

    /**
     * Indica si el token es un operador aritmético.
     *
     * @return true si el tipo es OPERADOR
     */
    public boolean esOperador() {
        return tipo == TipoToken.OPERADOR;
    }

    /**
     * Retorna la precedencia del operador (mayor número = mayor prioridad).
     * + y - tienen precedencia 1; * y / tienen precedencia 2.
     *
     * @return nivel de precedencia (1 o 2), 0 si no es operador
     */
    public int getPrecedencia() {
        if (!esOperador()) {
            return 0;
        }
        return (valor.equals("*") || valor.equals("/")) ? 2 : 1;
    }

    /**
     * Representación legible del token.
     *
     * @return cadena con tipo y valor, ej. [OPERADOR: +]
     */
    @Override
    public String toString() {
        return "[" + tipo + ": " + valor + "]";
    }
}

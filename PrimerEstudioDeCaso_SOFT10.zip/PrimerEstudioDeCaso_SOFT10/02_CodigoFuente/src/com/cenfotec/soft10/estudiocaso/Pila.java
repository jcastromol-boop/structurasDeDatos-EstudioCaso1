package com.cenfotec.soft10.estudiocaso;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementación personalizada de una Pila (LIFO) basada en nodos enlazados.
 * No utiliza java.util.Stack ni java.util.LinkedList: la estructura se
 * construye únicamente con punteros entre objetos Token.
 *
 * Complejidad: push(), pop() y peek() son O(1); el espacio es O(N).
 *
 * @author Estudiante de Ingeniería en Software - Universidad CENFOTEC
 * @version 1.0
 */
public class Pila {

    /** Nodo que representa la cima (tope) de la pila. */
    private Token cima;

    /** Cantidad de elementos almacenados. */
    private int tamaño;

    /**
     * Constructor: crea una pila vacía.
     */
    public Pila() {
        this.cima = null;
        this.tamaño = 0;
    }

    /**
     * Inserta un token en la cima de la pila (operación PUSH).
     * El nuevo nodo apunta al antiguo tope y se convierte en la cima.
     *
     * @param token elemento a insertar
     */
    public void push(Token token) {
        token.setSiguiente(cima);   // El nuevo nodo enlaza al anterior tope
        cima = token;               // El nuevo nodo se convierte en cima
        tamaño++;
        System.out.println("  PUSH -> se apiló " + token + " | Tamaño: " + tamaño);
    }

    /**
     * Extrae y retorna el token de la cima (operación POP).
     *
     * @return token de la cima
     * @throws IllegalStateException si la pila está vacía
     */
    public Token pop() {
        if (estaVacia()) {
            throw new IllegalStateException("Error: la pila está vacía. No se puede hacer POP.");
        }
        Token eliminado = cima;
        cima = cima.getSiguiente(); // La cima pasa a ser el nodo siguiente
        eliminado.setSiguiente(null); // Desenlazar por seguridad
        tamaño--;
        System.out.println("  POP  -> se extrajo " + eliminado + " | Tamaño: " + tamaño);
        return eliminado;
    }

    /**
     * Observa el token de la cima sin extraerlo (operación PEEK).
     *
     * @return token de la cima, o null si la pila está vacía
     */
    public Token peek() {
        return cima;
    }

    /**
     * Verifica si la pila no contiene elementos.
     *
     * @return true si la pila está vacía
     */
    public boolean estaVacia() {
        return cima == null;
    }

    /**
     * Retorna la cantidad de elementos de la pila.
     *
     * @return número de nodos almacenados
     */
    public int getTamaño() {
        return tamaño;
    }

    /**
     * Imprime la pila de arriba hacia abajo, simulando celdas
     * como las filas de una hoja de cálculo (Excel/Google Sheets).
     */
    public void imprimirPila() {
        if (estaVacia()) {
            System.out.println("  +---------------------+");
            System.out.println("  |   PILA VACÍA        |");
            System.out.println("  +---------------------+");
            return;
        }
        System.out.println("  +---------------------+  <- CIMA");
        Token actual = cima;
        while (actual != null) {
            int celda = tamaño - contarDesde(actual) + 1; // Numera como celdas de Excel
            System.out.printf("  | Celda %2d: %-8s |%n", celda, actual.getValor());
            actual = actual.getSiguiente();
        }
        System.out.println("  +---------------------+  <- FONDO");
        System.out.println("  Tamaño actual: " + tamaño);
    }

    /**
     * Cuenta cuántos nodos hay desde un nodo dado hasta el fondo.
     * Método auxiliar interno para numerar las celdas en la impresión.
     */
    private int contarDesde(Token nodo) {
        int contador = 0;
        Token actual = nodo;
        while (actual != null) {
            contador++;
            actual = actual.getSiguiente();
        }
        return contador;
    }

    /**
     * Retorna una representación en texto del contenido de la pila
     * de la cima hacia el fondo, útil para trazas paso a paso.
     *
     * @return lista de valores de la cima al fondo
     */
    public List<String> contenidoComoLista() {
        List<String> elementos = new ArrayList<>();
        Token actual = cima;
        while (actual != null) {
            elementos.add(actual.getValor());
            actual = actual.getSiguiente();
        }
        return elementos;
    }
}

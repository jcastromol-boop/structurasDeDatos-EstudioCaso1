package com.cenfotec.soft10.estudiocaso;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Punto de entrada de la aplicación: menú interactivo por consola
 * para el estudio de caso "Análisis de Expresiones Aritméticas con Pilas".
 *
 * Opciones:
 *   1. Ingresar y analizar una expresión aritmética.
 *   2. Ver el estado de la pila paso a paso.
 *   3. Probar operaciones fundamentales (Push, Pop, Peek).
 *   4. Salir.
 *
 * @author Estudiante de Ingeniería en Software - Universidad CENFOTEC
 * @version 1.0
 */
public class Main {

    /** Objeto para leer la entrada del usuario por consola. */
    private static final Scanner scanner = new Scanner(System.in);

    /** Pila manual para la opción 3 (pruebas directas). */
    private static final Pila pilaManual = new Pila();

    /** Analizador que contiene la lógica del estudio de caso. */
    private static final AnalizadorAritmetico analizador = new AnalizadorAritmetico();

    /**
     * Rutina principal: despliega el menú hasta que el usuario elija salir.
     *
     * @param args argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        mostrarBienvenida();
        boolean salir = false;

        while (!salir) {
            mostrarMenu();
            int opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    analizarExpresion();
                    break;
                case 2:
                    verPasoAPaso();
                    break;
                case 3:
                    probarOperacionesPila();
                    break;
                case 4:
                    salir = true;
                    System.out.println();
                    System.out.println("Gracias por usar el analizador. Saliendo del sistema...");
                    break;
                default:
                    System.out.println();
                    System.out.println(">> Opción no válida. Por favor ingrese un número del 1 al 4.");
            }
        }
        scanner.close();
    }

    /**
     * Muestra el encabezado de bienvenida del sistema.
     */
    private static void mostrarBienvenida() {
        System.out.println("+--------------------------------------------------+");
        System.out.println("|   ANALIZADOR DE EXPRESIONES ARITMÉTICAS          |");
        System.out.println("|   Estructura de Datos: PILA (LIFO)               |");
        System.out.println("|   Universidad CENFOTEC - SOFT-10                 |");
        System.out.println("+--------------------------------------------------+");
    }

    /**
     * Imprime las opciones disponibles del menú principal.
     */
    private static void mostrarMenu() {
        System.out.println();
        System.out.println("-------------- MENÚ PRINCIPAL ----------------");
        System.out.println("  1. Ingresar y analizar una expresión aritmética");
        System.out.println("  2. Ver el estado de la pila paso a paso");
        System.out.println("  3. Probar operaciones de la pila (Push, Pop, Peek)");
        System.out.println("  4. Salir");
        System.out.print("Seleccione una opción: ");
    }

    /**
     * Lee y valida la opción numérica del menú, tolerando entradas no numéricas.
     *
     * @return entero ingresado por el usuario (-1 si la entrada fue inválida)
     */
    private static int leerOpcion() {
        try {
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el salto de línea pendiente
            return opcion;
        } catch (InputMismatchException e) {
            scanner.nextLine(); // Descartar la entrada incorrecta
            System.out.println();
            System.out.println(">> Entrada inválida: debe ingresar un número entero.");
            return -1;
        }
    }

    /**
     * Opción 1: solicita una expresión, la tokeniza, valida el balanceo,
     * la convierte a postfijo y ofrece evaluarla con valores de variables.
     */
    private static void analizarExpresion() {
        System.out.println();
        System.out.println("=== OPCIÓN 1: ANÁLISIS DE EXPRESIÓN ===");
        System.out.println("Tokens soportados: números, variables (letras), operadores + - * / y paréntesis.");
        System.out.print("Ingrese la expresión aritmética (ej. a + (b * 5)): ");

        String entrada = scanner.nextLine().trim();
        if (entrada.isEmpty()) {
            System.out.println(">> La expresión no puede estar vacía.");
            return;
        }

        try {
            // Paso 1: Tokenización
            List<Token> tokens = analizador.tokenizar(entrada);
            System.out.println();
            System.out.println("1) TOKENIZACIÓN:");
            System.out.print("   ");
            for (Token t : tokens) {
                System.out.print(t + " ");
            }
            System.out.println();

            // Paso 2: Balanceo de paréntesis
            System.out.println();
            System.out.println("2) BALANCEO DE PARÉNTESIS:");
            String resultadoBalanceo = analizador.verificarBalanceo(tokens);
            System.out.println("   " + resultadoBalanceo);
            if (!resultadoBalanceo.contains("BALANCEADA CORRECTAMENTE")) {
                System.out.println("   Corrija la expresión e inténtelo de nuevo.");
                return;
            }

            // Paso 3: Conversión a postfijo (Shunting-yard)
            System.out.println();
            System.out.println("3) CONVERSIÓN A NOTACIÓN POSTFIJA (Shunting-yard):");
            List<Token> postfija = analizador.convertirAPostfija(tokens);
            System.out.print("   ");
            for (Token t : postfija) {
                System.out.print(t.getValor() + " ");
            }
            System.out.println();

            // Paso 4 (opcional): Evaluación numérica
            System.out.println();
            System.out.print("¿Desea evaluar la expresión con valores numéricos? (s/n): ");
            String respuesta = scanner.nextLine().trim().toLowerCase();
            if (respuesta.equals("s") || respuesta.equals("si")) {
                Map<String, Double> valores = solicitarValoresVariables(tokens);
                double resultado = analizador.evaluarPostfija(postfija, valores);
                System.out.println();
                System.out.printf("RESULTADO: %.4f%n", resultado);
            }

        } catch (IllegalArgumentException | ArithmeticException e) {
            System.out.println();
            System.out.println("!! Error en el análisis: " + e.getMessage());
        }
    }

    /**
     * Pide al usuario el valor numérico de cada variable presente en la expresión.
     *
     * @param tokens lista de tokens de la expresión analizada
     * @return mapa con los valores ingresados para cada variable
     */
    private static Map<String, Double> solicitarValoresVariables(List<Token> tokens) {
        Map<String, Double> valores = new HashMap<>();
        for (Token token : tokens) {
            if (token.getTipo() == Token.TipoToken.VARIABLE && !valores.containsKey(token.getValor())) {
                while (true) {
                    try {
                        System.out.print("   Ingrese el valor de '" + token.getValor() + "': ");
                        double valor = Double.parseDouble(scanner.nextLine().trim());
                        valores.put(token.getValor(), valor);
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println("   >> Valor inválido. Ingrese un número (ej. 3.5).");
                    }
                }
            }
        }
        return valores;
    }

    /**
     * Opción 2: muestra el registro detallado de push/pop generado
     * durante la última validación de balanceo.
     */
    private static void verPasoAPaso() {
        System.out.println();
        System.out.println("=== OPCIÓN 2: ESTADO DE LA PILA PASO A PASO ===");
        List<String> pasos = analizador.getRegistroPasos();

        if (pasos.isEmpty()) {
            System.out.println("Aún no se ha analizado ninguna expresión.");
            System.out.println("Use primero la opción 1 para generar un registro.");
            return;
        }

        System.out.println("Registro de la última validación realizada:");
        System.out.println();
        for (String paso : pasos) {
            System.out.println("  " + paso);
        }
        System.out.println();
        System.out.println("(La notación [x, y] muestra la pila de la CIMA (izquierda) al FONDO (derecha).)");
    }

    /**
     * Opción 3: submenú para probar manualmente push, pop y peek
     * sobre la pila manual.
     */
    private static void probarOperacionesPila() {
        System.out.println();
        System.out.println("=== OPCIÓN 3: PRUEBA MANUAL DE LA PILA ===");
        boolean volver = false;

        while (!volver) {
            System.out.println();
            System.out.println("  --- Submenú de operaciones ---");
            System.out.println("  a. PUSH (apilar un token)");
            System.out.println("  b. POP (extraer de la cima)");
            System.out.println("  c. PEEK (ver la cima sin extraer)");
            System.out.println("  d. Ver estado completo de la pila");
            System.out.println("  e. Volver al menú principal");
            System.out.print("  Seleccione una operación: ");

            String op = scanner.nextLine().trim().toLowerCase();

            switch (op) {
                case "a":
                    System.out.print("  Ingrese el valor del token: ");
                    String valor = scanner.nextLine().trim();
                    if (valor.isEmpty()) {
                        System.out.println("  >> El valor no puede estar vacío.");
                        break;
                    }
                    Token.TipoToken tipo = deducirTipo(valor);
                    pilaManual.push(new Token(valor, tipo));
                    break;

                case "b":
                    try {
                        Token extraido = pilaManual.pop();
                        System.out.println("  Token extraído de la cima: " + extraido);
                    } catch (IllegalStateException e) {
                        System.out.println("  >> " + e.getMessage());
                    }
                    break;

                case "c":
                    Token cima = pilaManual.peek();
                    if (cima == null) {
                        System.out.println("  La pila está vacía. No hay cima que observar.");
                    } else {
                        System.out.println("  Cima actual (sin extraer): " + cima);
                    }
                    break;

                case "d":
                    pilaManual.imprimirPila();
                    break;

                case "e":
                    volver = true;
                    break;

                default:
                    System.out.println("  >> Opción inválida. Use a, b, c, d o e.");
            }
        }
    }

    /**
     * Deduce el tipo de token a partir de su texto, para la carga manual.
     *
     * @param valor texto ingresado por el usuario
     * @return tipo de token inferido
     */
    private static Token.TipoToken deducirTipo(String valor) {
        if (valor.matches("[0-9]+(\\.[0-9]+)?")) {
            return Token.TipoToken.NUMERO;
        } else if (valor.matches("[+\\-*/]")) {
            return Token.TipoToken.OPERADOR;
        } else if (valor.equals("(")) {
            return Token.TipoToken.PARENTESIS_IZQ;
        } else if (valor.equals(")")) {
            return Token.TipoToken.PARENTESIS_DER;
        } else {
            return Token.TipoToken.VARIABLE;
        }
    }
}
